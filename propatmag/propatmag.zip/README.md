# propatmag

Control magnético de actitud usando propat.