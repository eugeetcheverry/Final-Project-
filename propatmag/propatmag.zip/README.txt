	

	Propat instructions:

		1) Unpack the propat.zip file in any folder.
		2) From the Matlab console go to the propat folder:

			>>cd 'c:\My Folder\Matlab\propat'

		3) Get help with

			>>help propat

		That's all

		Valdemir
